const apiBase = '../Account%20functions/api.php';
const sessionKey = 'vicom-session';
const session = getSession();
const artistId = new URLSearchParams(window.location.search).get('id') || session?.userId;
const nameElement = document.querySelector('#artist-name');
const specialtyElement = document.querySelector('#artist-specialty');
const descriptionElement = document.querySelector('#profile-description');
const socialLinkElement = document.querySelector('#artist-social-link');
const avatarElement = document.querySelector('#artist-avatar');
const grid = document.querySelector('#portfolio-grid');
const empty = document.querySelector('#empty-state');
const count = document.querySelector('#work-count');
const toast = document.querySelector('#toast');
const descriptionPanel = document.querySelector('#description-panel');
const descriptionInput = document.querySelector('#description-input');
const socialLinkInput = document.querySelector('#social-link-input');
const formError = document.querySelector('#form-error');
let artist;

function getSession() {
  try {
    return JSON.parse(localStorage.getItem(sessionKey) || 'null');
  } catch {
    return null;
  }
}

function showToast(message) {
  toast.textContent = message;
  toast.classList.add('show');
  setTimeout(() => toast.classList.remove('show'), 2200);
}

function renderProfile(profile) {
  artist = profile.artist;
  document.title = `ViCom | ${artist.name}`;
  nameElement.textContent = artist.name;
  specialtyElement.textContent = artist.specialty || 'Original commissions';
  descriptionElement.textContent = artist.description || 'Original work made with care, clarity, and a point of view.';
  renderSocialLink(artist.socialLink);
  avatarElement.textContent = artist.name.trim().charAt(0).toUpperCase();

  const artworks = profile.artworks || [];
  count.textContent = `${artworks.length} ${artworks.length === 1 ? 'piece' : 'pieces'}`;
  grid.innerHTML = artworks.map((work) => `
    <article class="work-card">
      <div class="work-image" style="background-image:url('${work.image}')" data-image="${work.image}" role="button" tabindex="0" aria-label="View ${work.title}"></div>
      <div class="work-meta"><div><h3>${work.title}</h3><p>${work.detail || work.category}</p></div></div>
    </article>`).join('');
  empty.hidden = artworks.length > 0;
}

function renderSocialLink(url) {
  if (url) {
    socialLinkElement.href = url;
    socialLinkElement.textContent = url;
    socialLinkElement.hidden = false;
  } else {
    socialLinkElement.removeAttribute('href');
    socialLinkElement.textContent = '';
    socialLinkElement.hidden = true;
  }
}

async function loadProfile() {
  if (!session?.userId || session.role !== 'artist') {
    window.location.href = '../Account%20functions/auth.html?mode=signin';
    return;
  }
  try {
    const response = await fetch(`${apiBase}?action=artist&id=${encodeURIComponent(artistId)}`);
    const profile = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(profile.error || 'Profile unavailable.');
    if (artistId !== session.userId) throw new Error('You can only edit your own profile.');
    renderProfile(profile);
    descriptionInput.value = artist.description || '';
    socialLinkInput.value = artist.socialLink || '';
  } catch (error) {
    nameElement.textContent = 'Profile unavailable';
    empty.hidden = false;
    empty.textContent = error.message;
    document.querySelector('#edit-description').hidden = true;
  }
}

document.querySelector('#edit-description').addEventListener('click', () => {
  descriptionPanel.hidden = false;
  descriptionInput.focus();
});

document.querySelector('#cancel-description').addEventListener('click', () => {
  descriptionPanel.hidden = true;
  formError.textContent = '';
  descriptionInput.value = artist?.description || '';
  socialLinkInput.value = artist?.socialLink || '';
});

document.querySelector('#save-description').addEventListener('click', async () => {
  const description = descriptionInput.value.trim();
  const socialLink = socialLinkInput.value.trim();
  const saveButton = document.querySelector('#save-description');
  formError.textContent = '';
  saveButton.disabled = true;
  try {
    const response = await fetch(`${apiBase}?action=update_profile`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        id: session.userId,
        email: session.email,
        name: session.name,
        specialty: session.specialty || artist.specialty || '',
        description,
        socialLink,
        password: '',
      }),
    });
    const result = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(result.error || 'Could not save description.');
    artist.description = result.user.description;
    artist.socialLink = result.user.socialLink;
    descriptionElement.textContent = description || 'Original work made with care, clarity, and a point of view.';
    renderSocialLink(artist.socialLink);
    descriptionPanel.hidden = true;
    showToast('Description updated');
  } catch (error) {
    formError.textContent = error.message;
  } finally {
    saveButton.disabled = false;
  }
});

const lightbox = document.querySelector('#lightbox');
const lightboxImage = document.querySelector('#lightbox-image');
function closeLightbox() {
  lightbox.classList.remove('open');
  lightbox.setAttribute('aria-hidden', 'true');
  lightboxImage.style.backgroundImage = '';
}
function openLightbox(image) {
  lightboxImage.style.backgroundImage = `url("${image}")`;
  lightbox.classList.add('open');
  lightbox.setAttribute('aria-hidden', 'false');
}
grid.addEventListener('click', (event) => {
  const image = event.target.closest('.work-image');
  if (image) openLightbox(image.dataset.image);
});
grid.addEventListener('keydown', (event) => {
  if ((event.key === 'Enter' || event.key === ' ') && event.target.matches('.work-image')) {
    event.preventDefault();
    openLightbox(event.target.dataset.image);
  }
});
document.querySelector('#lightbox-close').addEventListener('click', closeLightbox);
lightbox.addEventListener('click', (event) => {
  if (event.target === lightbox) closeLightbox();
});
document.addEventListener('keydown', (event) => {
  if (event.key === 'Escape' && lightbox.classList.contains('open')) closeLightbox();
});

loadProfile();

/* ══════════════════════════════════════════
   RATES MANAGEMENT
══════════════════════════════════════════ */
const RATES_KEY = 'vicom-rates';
let editingRateIndex = null;

function getRates() {
  try {
    const all = JSON.parse(localStorage.getItem(RATES_KEY) || '{}');
    return Array.isArray(all[session.userId]) ? all[session.userId] : [];
  } catch { return []; }
}

function saveRates(rates) {
  try {
    const all = JSON.parse(localStorage.getItem(RATES_KEY) || '{}');
    all[session.userId] = rates;
    localStorage.setItem(RATES_KEY, JSON.stringify(all));
  } catch {}
}

function renderRates() {
  const ratesGrid = document.querySelector('#rates-grid');
  const ratesEmpty = document.querySelector('#rates-empty');
  if (!ratesGrid) return;
  const rates = getRates();
  if (rates.length === 0) {
    ratesGrid.innerHTML = '';
    ratesEmpty.hidden = false;
    return;
  }
  ratesEmpty.hidden = true;
  ratesGrid.innerHTML = rates.map((rate, i) => `
    <article class="rate-card" data-index="${i}">
      <div class="rate-card-body">
        <p class="rate-card-type">${rate.type || 'Commission'}</p>
        <p class="rate-card-desc">${rate.description || ''}</p>
        <span class="rate-card-price">from ₱${Number(rate.price).toLocaleString()}</span>
        <div class="rate-card-actions">
          <button class="rate-card-edit" type="button" data-action="edit" data-index="${i}">Edit</button>
          <button class="rate-card-delete" type="button" data-action="delete" data-index="${i}">Delete</button>
        </div>
      </div>
    </article>`).join('');
}

function openRateModal(editIndex = null) {
  editingRateIndex = editIndex;
  const modal = document.querySelector('#rate-modal-overlay');
  const titleEl = document.querySelector('#rate-modal-title');
  const typeEl = document.querySelector('#rate-type');
  const descEl = document.querySelector('#rate-description');
  const priceEl = document.querySelector('#rate-price');
  const errEl = document.querySelector('#rate-error');

  errEl.textContent = '';

  if (editIndex !== null) {
    const rate = getRates()[editIndex];
    titleEl.textContent = 'Edit service';
    typeEl.value = rate.type || 'Portrait';
    descEl.value = rate.description || '';
    priceEl.value = rate.price;
  } else {
    titleEl.textContent = 'Add a service & rate';
    typeEl.value = 'Portrait';
    descEl.value = '';
    priceEl.value = '';
  }

  modal.classList.add('open');
  modal.setAttribute('aria-hidden', 'false');
  typeEl.focus();
}

function closeRateModal() {
  document.querySelector('#rate-modal-overlay').classList.remove('open');
  document.querySelector('#rate-modal-overlay').setAttribute('aria-hidden', 'true');
  editingRateIndex = null;
}

// Save rate card
document.querySelector('#rate-save-btn')?.addEventListener('click', () => {
  const typeVal = document.querySelector('#rate-type').value.trim();
  const descVal = document.querySelector('#rate-description').value.trim();
  const priceVal = document.querySelector('#rate-price').value.trim();
  const errEl = document.querySelector('#rate-error');

  errEl.textContent = '';
  if (!typeVal) { errEl.textContent = 'Please choose a type of work.'; return; }
  if (!priceVal || Number(priceVal) < 1) { errEl.textContent = 'Please enter a rate.'; return; }

  const rateObj = { type: typeVal, description: descVal, price: Number(priceVal) };

  const rates = getRates();
  if (editingRateIndex !== null) {
    rates[editingRateIndex] = rateObj;
  } else {
    rates.push(rateObj);
  }
  saveRates(rates);
  renderRates();
  closeRateModal();
  showToast(editingRateIndex !== null ? 'Service updated' : 'Service added');
});

// Delete rate
document.querySelector('#rates-grid')?.addEventListener('click', (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;
  const idx = Number(btn.dataset.index);
  if (btn.dataset.action === 'edit') {
    openRateModal(idx);
  } else if (btn.dataset.action === 'delete') {
    const rates = getRates();
    rates.splice(idx, 1);
    saveRates(rates);
    renderRates();
    showToast('Rate card removed');
  }
});

document.querySelector('#add-rate-btn')?.addEventListener('click', () => openRateModal(null));
document.querySelector('#rate-modal-close')?.addEventListener('click', closeRateModal);
document.querySelector('#rate-cancel-btn')?.addEventListener('click', closeRateModal);
document.querySelector('#rate-modal-overlay')?.addEventListener('click', (e) => {
  if (e.target.id === 'rate-modal-overlay') closeRateModal();
});

renderRates();
